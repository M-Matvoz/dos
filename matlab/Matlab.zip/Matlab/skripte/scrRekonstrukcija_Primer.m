addpath('../lib');

Tvz = 3/8;
t = -Tvz:0.01:(3+Tvz);


x = [0 2 0 0 0 -2 0 0 0 2];

sinc0 = fnSinc(pi*t/Tvz); nTvz = (-1:8)*Tvz;
sinc1 = fnSinc(pi*(t/Tvz-1));
sinc2 = fnSinc(pi*(t/Tvz-2));
sinc3 = fnSinc(pi*(t/Tvz-3));
sinc4 = fnSinc(pi*(t/Tvz-4));
sinc5 = fnSinc(pi*(t/Tvz-5));
sinc6 = fnSinc(pi*(t/Tvz-6));
sinc7 = fnSinc(pi*(t/Tvz-7));
sinc8 = fnSinc(pi*(t/Tvz-8));

%% rekonstrukcija po delih
plot(t, sinc0*2, 'b'), hold on
plot(t, sinc1*0, 'r')
plot(t, sinc2*0, 'g')
plot(t, sinc3*0, 'm')
plot(t, sinc4*(-2), 'c')
plot(t, sinc5*0, 'k')
plot(t, sinc6*0, 'k')
plot(t, sinc7*0, 'k')
plot(t, sinc8*2, 'b')
xlabel('{\itt} [ms]'), ylabel('{\itx}[{\itn}] sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))')

plot(nTvz, x, '*b')

%% rekonstrukcija cela

f = 1; fvz = 8/3; n = -1:8; t = -3/8:0.01:3+3/8;
plot(t, cos(2*pi*f*t)+cos(2*pi*f*t/3), 'Color', [1 0 1]), hold on
x4 = cos(2*pi*f/fvz*n) + cos(2*pi*f/fvz*n/3);
plot(n*3/8, x4, 'o', 'MarkerFaceColor', [1 0 1]), xlabel('t'), ylabel('x(t)')
plot(n*3/8, x4, 'b')
line([-3/8 -3/16], [0 0], 'Color', 'g')
line([-3/16 -3/16], [0 2], 'Color', 'g')
line([-3/16 3/16], [2 2], 'Color', 'g')
line([3/16 3/16], [2 0], 'Color', 'g')
line([3/16 3/2-3/16], [0 0], 'Color', 'g')
line([3/2-3/16 3/2-3/16], [0 -2], 'Color', 'g')
line([3/2-3/16 3/2+3/16], [-2 -2], 'Color', 'g')
line([3/2+3/16 3/2+3/16], [-2 0], 'Color', 'g')
line([3/2+3/16 3-3/16], [0 0], 'Color', 'g')
line([3-3/16 3-3/16], [0 2], 'Color', 'g')
line([3-3/16 3+3/16], [2 2], 'Color', 'g')
line([3+3/16 3+3/16], [2 0], 'Color', 'g')



x = [2 0 0 0 -2 0 0 0];
x = [x x x x x x];
x = [x x x x x x];
xr = fnInterpolateWithSinc(x,1000);
%xr = fnInterpolateWithSquare(x,1000);
t4plot = -Tvz:(3+2*Tvz)/length(xr):3+Tvz; t4plot=t4plot(1:end-1);
plot(t4plot, xr)
xlabel('t [ms]'), ylabel('xr(t)')

%% Rekonstrukcija 1 -1
x = [0 0 0 1 -1 1 -1 1 -1 1 -1 1 -1 0 0 0 0 0];
xr = fnInterpolateWithSinc(x,1000);



% 
% hold on
% f = 1; t = 0:0.01:3;
% plot(t, cos(2*pi*f*t)+cos(2*pi*f*t/3), 'Color', [1 0 1])