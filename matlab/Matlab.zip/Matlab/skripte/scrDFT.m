addpath('data/glazba');
addpath('lib');

[x, fs] = audioread('John Coltrane - Blue train.mp3'); x = x(1:fs*20,1);
[x, fs] = audioread('John Coltrane - Blue train - LP.wav'); x = x(1:fs*20,1);
[x, fs] = audioread('John Coltrane - Blue train - HP.wav'); x = x(1:fs*20,1);
[x fs] = audioread('data/glazba/A walk in the park NP.wav');
[x fs] = audioread('data/glazba/A walk in the park VP.wav');

p = audioplayer(x,fs);

x = imread('data/slike/malevic.png');
imshow(x);
x = x(255,:);

x = imread('data/slike/Pollock.jpg');
imshow(x);
x = rgb2gray(x);
x = x(255,:);

[X,Ax,phix] = fnFFT(x);
fnPlotDFT(x,Ax);


% %% generiranje crnega kvadrata na beli podlagi
x = [];
for i = 1:128 
    x(i,1:512) = 255;
end
for i = 129:129+128*2-1
    for j = 1:128
        x(i,j) = 255;
    end
    for j = 129:129+128*2-1
        x(i,j) = 0;
    end
    for j = 129+128*2:512
        x(i,j) = 255;
    end
end
for i = 129+128*2:512 
    x(i,1:512) = 255;
end

imwrite(x,'MalevicCrniKvadratNaBeliPodlagi.png');
