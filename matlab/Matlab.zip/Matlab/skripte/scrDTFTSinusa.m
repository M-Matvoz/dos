%% prehod iz DFT do DTFT za poljuben omejen signal z upoštevanjem oknjenja 
%% s pravokotnim oknom in konvolucije v frekvenčnem prostoru
N = 64; n = 0:N-1;
x1N = sin(2*pi/N*n);
xAP = [zeros(1,N) zeros(1,N) x1N zeros(1,N) zeros(1,N)];
xP = [x1N x1N x1N x1N x1N];
figure;
subplot(221)
stem(xP,'.k', 'MarkerSize', 8, 'LineWidth', 0.6)
line([N*2+1, N*2+1], [-1,1],'Color','r'),line([N*3, N*3], [-1,1],'Color','r'), line([N*2+1, N*3], [1,1],'Color','r'),line([N*2+1, N*3], [-1,-1],'Color','r')
xlabel('$n$', 'Interpreter', 'Latex'),ylabel('$x[n]$', 'Interpreter', 'Latex')
subplot(223)
stem(xAP,'.k', 'MarkerSize', 8, 'LineWidth', 0.6)
line([N*2+1, N*2+1], [-1,1],'Color','r'),line([N*3, N*3], [-1,1],'Color','r'), line([N*2+1, N*3], [1,1],'Color','r'),line([N*2+1, N*3], [-1,-1],'Color','r')
xlabel('$n$', 'Interpreter', 'Latex'),ylabel('$x[n]$', 'Interpreter', 'Latex')

[XP,AXP,phiXP] = fnDFT(x1N);
subplot(222)
stem(AXP,'.k', 'MarkerSize', 8, 'LineWidth', 0.6)
xlabel('$k$', 'Interpreter', 'Latex'),ylabel('$A_X[k]$', 'Interpreter', 'Latex')
subplot(224)
stem(AXP,'.k', 'MarkerSize', 8, 'LineWidth', 0.6)
xlabel('$k$', 'Interpreter', 'Latex'),ylabel('$A_X[k]$', 'Interpreter', 'Latex')

%% izris DTFT od 0 do 2pi
omega = linspace(0,2*pi,2000);
[XAP,AXAP,phiXAP] = fnDTFT(xAP,omega);
fig=figure;
plot(linspace(0,2*pi,length(AXAP)),AXAP, 'k', 'LineWidth', 0.6);
xlabel('\it\Omega'),ylabel('{\itA} ({\it\Omega})')
axis([0 2*pi 0 1.1*max(AXAP)]);ax=gca;
ax.XTick=[0,pi/2,pi,3*pi/2,2*pi];
ax.XTickLabel={'0','\it\pi/2','\it\pi','\it3\pi/2','\it2\pi'};

%% izris od minus pi do pi
omega = linspace(-pi,pi,2000);
[XAP,AXAP,phiXAP] = fnDTFT(xAP,omega);
fig=figure;
plot(linspace(-pi,pi,length(AXAP)),AXAP, 'k', 'LineWidth', 0.6);
xlabel('\it\Omega'),ylabel('{\itA} ({\it\Omega})')
axis([-pi pi 0 1.1*max(AXAP)]);ax=gca;
ax.XTick=[-pi,-pi/2,0,pi/2,pi];
ax.XTickLabel={'-\it\pi','-\it\pi/2','0','\it\pi/2','\it\pi'};


%% periodičnost DTFT 
x3 = xAP;
%x3 = hann(20); 
omega = linspace(-2*pi,2*pi,2000);
[X3,AX3,phiX3,a3] = fnDTFT3(x3, omega);
fig=figure;
plot(omega,AX3, 'k', 'LineWidth', 0.6);
xlabel('\it\Omega'),ylabel('{\itA} ({\it\Omega})')
axis([-2*pi 2*pi 0 1.1*max(AX3)]);ax=gca;
ax.XTick=[-2*pi,-pi,0,pi,2*pi];
ax.XTickLabel={'-2\it\pi','-\it\pi','0','\it\pi','2\it\pi'};

%% DTFT ene in polovice periode
x3 = x1N;
%x3 = hann(20); 
omega = linspace(-pi,pi,2000);
[X3,AX3,phiX3,a3] = fnDTFT3(x3, omega);
fig=figure; hold on
plot(omega,AX3, 'k', 'LineWidth', 0.6);
xlabel('\it\Omega'),ylabel('{\itA} ({\it\Omega})')
axis([-pi pi 0 1.1*max(AX3)]);ax=gca;
ax.XTick=[-pi,-pi/2,0,pi/2,pi];
ax.XTickLabel={'-\it\pi','-\it\pi/2','0','\it\pi','\it\pi/2'};
x3 = [x1N x1N];
%x3 = hann(20); 
[X3,AX3,phiX3,a3] = fnDTFT3(x3, omega);
plot(omega,AX3, 'r', 'LineWidth', 0.6);



