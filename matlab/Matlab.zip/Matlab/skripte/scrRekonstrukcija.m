t = -2:0.01:10;
Tvz = 1;

sinc0 = fnSinc(pi*t/Tvz); nTvz = -2:10;
sinc1 = fnSinc(pi*(t/Tvz-1));
sinc2 = fnSinc(pi*(t/Tvz-2));
sinc3 = fnSinc(pi*(t/Tvz-3));
sinc4 = fnSinc(pi*(t/Tvz-4));
sinc5 = fnSinc(pi*(t/Tvz-5));
sinc6 = fnSinc(pi*(t/Tvz-6));
sinc7 = fnSinc(pi*(t/Tvz-7));
sinc8 = fnSinc(pi*(t/Tvz-8));

plot(t, sinc0, 'b'), hold on
xlabel('{\itt} [{\itT_{vz}}]'), ylabel('sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))'),
plot(nTvz, fnSinc(pi*nTvz), '*b'), legend('sinc({\pi\it/T_{vz}t})');

plot(t, sinc0, 'b'), hold on
plot(t, sinc1, 'r')
xlabel('{\itt} [{\itT_{vz}}]'), ylabel('sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))'),
plot(nTvz, fnSinc(pi*nTvz), '*b')
plot(nTvz, fnSinc(pi*(nTvz-1)), '*r'), legend('sinc({\pi\it/T_{vz}t})', 'sinc({\pi\it/T_{vz}}({\itt-T_{vz}}))');

plot(t, sinc0, 'b'), hold on
plot(t, sinc1, 'r')
plot(t, sinc2, 'g')
xlabel('{\itt} [{\itT_{vz}}]'), ylabel('sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))')
plot(nTvz, fnSinc(pi*nTvz), '*b')
plot(nTvz, fnSinc(pi*(nTvz-1)), '*r')
plot(nTvz, fnSinc(pi*(nTvz-2)), '*g')
legend('sinc({\pi\it/T_{vz}t})', 'sinc({\pi\it/T_{vz}}({\itt-T_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}2{\itT_{vz}}))');

plot(t, sinc0, 'b'), hold on
plot(t, sinc1, 'r')
plot(t, sinc2, 'g')
plot(t, sinc3, 'm')
xlabel('{\itt} [{\itT_{vz}}]'), ylabel('sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))')
plot(nTvz, fnSinc(pi*nTvz), '*b')
plot(nTvz, fnSinc(pi*(nTvz-1)), '*r')
plot(nTvz, fnSinc(pi*(nTvz-2)), '*g')
plot(nTvz, fnSinc(pi*(nTvz-3)), '*m')
legend('sinc({\pi\it/T_{vz}t})', 'sinc({\pi\it/T_{vz}}({\itt-T_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}2{\itT_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}3{\itT_{vz}}))');

plot(t, sinc0, 'b'), hold on
plot(t, sinc1, 'r')
plot(t, sinc2, 'g')
plot(t, sinc3, 'm')
plot(t, sinc4, 'c')
xlabel('{\itt} [{\itT_{vz}}]'), ylabel('sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))')
plot(nTvz, fnSinc(pi*nTvz), '*b')
plot(nTvz, fnSinc(pi*(nTvz-1)), '*r')
plot(nTvz, fnSinc(pi*(nTvz-2)), '*g')
plot(nTvz, fnSinc(pi*(nTvz-3)), '*m')
plot(nTvz, fnSinc(pi*(nTvz-4)), '*c'), 
legend('sinc({\pi\it/T_{vz}t})', 'sinc({\pi\it/T_{vz}}({\itt-T_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}2{\itT_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}3{\itT_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}4{\itT_{vz}}))');



plot(t, sinc0, 'b'), hold on
plot(t, sinc1, 'r')
plot(t, sinc2, 'g')
plot(t, sinc3, 'm')
plot(t, sinc4, 'c')
plot(t, sinc5, 'k')
xlabel('{\itt} [{\itT_{vz}}]'), ylabel('sinc({\pi\it/T_{vz}}({\itt-nT_{vz}}))')
plot(nTvz, fnSinc(pi*nTvz), '*b')
plot(nTvz, fnSinc(pi*(nTvz-1)), '*r')
plot(nTvz, fnSinc(pi*(nTvz-2)), '*g')
plot(nTvz, fnSinc(pi*(nTvz-3)), '*m')
plot(nTvz, fnSinc(pi*(nTvz-4)), '*c')
plot(nTvz, fnSinc(pi*(nTvz-5)), '*k')
legend('sinc({\pi\it/T_{vz}t})', 'sinc({\pi\it/T_{vz}}({\itt-T_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}2{\itT_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}3{\itT_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}4{\itT_{vz}}))', 'sinc({\pi\it/T_{vz}}({\itt-}5{\itT_{vz}}))');
