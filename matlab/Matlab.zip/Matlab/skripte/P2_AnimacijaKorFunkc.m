N = 4; n = 0:N-1;

%% Naloga g)
x = sin(2*pi/N*n);
y = [1 0 0 0];

R = fnKorelacijskaFunkcija(x,y);
stem(n,R,'.')

%% Naloga h)
N = 256; n = 0:N-1;
x = 2*sin(2*pi/N*n);
y = 2*sin(2*pi/N*n);


N = 10; n = 0:N-1;
x = [ones(1,5) zeros(1,5)];
y = [0 0 ones(1,5) 0 0 0];


N = 100; n = 0:N-1;
x = [ones(1,10) zeros(1,N-10)];
y = [zeros(1,N-10) (1:10)*0.1];

figure;
subplot(121)
stem(n,x,'.')
subplot(122)
stem(n,y,'.')


N = 100; n = 0:N-1;
x = sin(2*pi/N*n); %% sinusni signal
y = [1 zeros(1,N-1)]; %% delta impulz

x = [ones(1,N/2) zeros(1,N/2)]; %% sinusni signal
y = [zeros(1,N/2) ones(1,N/2)]; %% sinusni signal
R = fnKorelacijskaFunkcija(x,y);

figure;
ytemp = y;
for i = 1:N
    subplot(211), 
    stem(n,x,'.','Color',[1 0 0]), hold on
    stem(n,ytemp,'.','Color',[0 0 1]), hold off
    xlabel('$n$','Interpreter','Latex')
    ylabel('$x\ [n], y\ [n]$','Interpreter','Latex')
    subplot(212)
    R = fnKorelacijskaFunkcija(x,y);
    stem(n,R,'.'), hold on
    plot(n(i),R(i),'*'), hold off
    xlabel('$n$','Interpreter','Latex')
    ylabel('$R_{xy}\ [n]$','Interpreter','Latex')
    ytemp = [ytemp(2:end) ytemp(1)];
    pause(0.5)
end


