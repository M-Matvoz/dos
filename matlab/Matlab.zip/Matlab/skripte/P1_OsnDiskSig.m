addpath('../lib')
fnKrozenjeKompleksorjaRealImag(0.75,0,2*pi/16*10,(0:15),0.5)
fnSestevanjeDvehKompleksorjev(1,0,2*pi/32,1,0,-2*pi/32,(0:31),0.5)




