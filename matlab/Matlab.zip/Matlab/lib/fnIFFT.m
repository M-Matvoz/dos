function x=fnIFFT(X)

x=ifft(X)*length(X);