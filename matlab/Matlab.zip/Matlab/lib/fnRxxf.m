function Rxx=fnRxxf(x)

    Rxx=fnRxyf(x,x);

end
