function mSig=fnCalMeanPower(sig,N)
    mSig=sum(sig.^2)/N;
end