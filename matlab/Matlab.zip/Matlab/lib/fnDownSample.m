function xout=fnDownSample(x,D)

xout=x(1:D:end);