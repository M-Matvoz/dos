function xc=fnGetSine(t,T,phi0)
    xc=sin(2*pi/T*t+phi0);
end